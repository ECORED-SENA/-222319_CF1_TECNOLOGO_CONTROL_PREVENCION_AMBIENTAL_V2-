function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Lu2iWkkrUw":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

